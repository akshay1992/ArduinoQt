Qt Project Template for Arduino
======================

This directory can be used as a template for making an Arduino project on QtCreator. Use with the `new_project.sh` shell script that accompanies this zip folder. 

## Renaming

* To rename the files in the project run the bash script
	`./rename.sh <new_name>`
	This will replace `HelloWorld` in all the filenames with whatever you specify in <new_name> 

## For reading serial data use this command:

	gtkterm --port /dev/ttyACMx --speed <serial_speed>

Replace the x in ACMx according to the port that the arduino is connected to. (Eg. ACM0)

## Settings Reference (No need to do this, it should be pre-configured in the `<PROJECT>.creator.user` file)

* Open QtCreator and open file/project. Open the .create file that is withing this project directory.

* In build settings, ensure that the build directory is `<PROJECT_FOLDER>/src`. This is so that it finds the `MakeFile`

* In run settings, add a new deploy step with Make. Set the following:
    * Override make: make
	* Make arguments: raw_upload

* In run configuration, add a custom executable. (This is just a dummy) 
	* Executable: echo 

## This template was made from the following tutorials:

* http://www.geekbraindump.com/2014/08/18/arduino-development-using-qtcreator-ide-in-linux/
* http://www.jayway.com/2011/09/22/using-qtcreator-for-arduino-development/
