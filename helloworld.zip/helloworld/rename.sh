#!/bin/bash

mv *.config $1.config
mv *.creator $1.creator
mv *.creator.user $1.creator.user
mv *.files $1.files
mv *.includes $1.includes

