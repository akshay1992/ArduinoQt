#!/bin/bash

find . -type f -name "HelloWorld*" -print0 | while read -r -d '' file; do
    mv "$file" "${file//HelloWorld/$1}"
done
